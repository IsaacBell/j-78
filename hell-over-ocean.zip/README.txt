A Pen created at CodePen.io. You can find this one at https://codepen.io/IsaacBell/pen/rrozEj.

 Exploring shaders, noise and fbm. The result is scary.